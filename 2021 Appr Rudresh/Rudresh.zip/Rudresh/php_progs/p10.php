<?php
$x=10;
$y=true;
$z=1.5;
$a="helo";// only data wise diffrent"" and ' '
$b=false;
echo "The type of ",$x," is ",gettype($x);
echo "\n";
echo "The type of ",$y," is ",gettype($y);
echo "\n";
echo "The type of ",$z," is ",gettype($z);
echo "\n";
echo "The type of ",$a," is ",gettype($a);
echo "\n";
echo "The type of ",$b," is ",gettype($b);
?>