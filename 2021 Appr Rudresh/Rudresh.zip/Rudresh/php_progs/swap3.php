<?php
$x=20;
$y=10;
$z=$x;
$x=$y;
$y=$z;
echo $x;
echo $y;