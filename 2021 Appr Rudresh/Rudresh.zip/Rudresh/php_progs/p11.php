<?php
# wap to emplement command line argument
print_r($argv[0]);
echo gettype($argv);
?>
