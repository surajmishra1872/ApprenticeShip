<?php
$n=10;
for($i=1;$i<=10;$i++){
$table =$i*$n;
echo $table."\n";
}
