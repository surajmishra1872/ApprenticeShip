<!Doctype html>
<html>
	<head>
<style>
#row1
{
height:500px;
border:1px solid red;
width:100%;
background:blue;
}
#row2
{
height:500px;
border:1px solid red;
width:100%;
background:blue;
}
#row3
{
height:500px;
border:1px solid red;
width:100%;
background:blue;
}
#row4
{
height:500px;
border:1px solid red;
width:100%;
background:blue;
}
</style>
</head>
	<body>
<div id="row1"></div>
<div id="row2"></div>
<div id="row3"></div>
<div id="row4"></div>
	</body>
<html>