<?php
include'scanner.php';
$x =input("Enter First Number");
$res = 3.47*$x*$x;
echo "area of $x  = ",$res;
?>