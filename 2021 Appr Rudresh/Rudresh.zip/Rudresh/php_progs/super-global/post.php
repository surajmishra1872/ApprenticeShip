<?php

$name = $_POST['f'];
echo $name;
?>