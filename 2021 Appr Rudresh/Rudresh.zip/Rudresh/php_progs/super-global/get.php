<?php
$name = $_GET['f'];
echo $name;
?>