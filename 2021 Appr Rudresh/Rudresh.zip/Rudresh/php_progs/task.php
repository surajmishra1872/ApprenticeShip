include 'scanner.php';
$x = printf(input("Enter User Name :  "));
echo "\nlength is $x";