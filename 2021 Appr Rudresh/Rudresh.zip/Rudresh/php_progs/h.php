#wap in php  to show use of sizeof and count
print_r(count($argv));
echo "\n";
print_r(count($argv));


