<?php
//echo "Hello World Again"," bye";
print "Hello from Print"," Bye from print";
?>