<?php
$x=20;
$y=10;
$x=$x+$y;
$y=$x-$y;
$x=$x-$y;
echo $x;
echo $y;