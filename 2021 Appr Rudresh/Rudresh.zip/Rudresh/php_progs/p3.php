<?php
#using scanner function to take input from the cmd
//import the scanner file
include"scanner.php";
$x=input('Enter a No: ');
echo $x;

?>