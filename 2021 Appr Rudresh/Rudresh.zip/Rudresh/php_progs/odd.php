<?php
include'scanner.php';
$n =input("Enter a Number");
if($n%2==0){
echo "$n  is even No";
}else{
echo $n."is odd no";
}