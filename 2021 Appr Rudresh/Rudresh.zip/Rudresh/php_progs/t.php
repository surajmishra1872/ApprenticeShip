<?php
#wap in php to show local inbuild server
echo "<h1>Hello world</h1>";
echo '<h1>Hello world</h1>';
?>