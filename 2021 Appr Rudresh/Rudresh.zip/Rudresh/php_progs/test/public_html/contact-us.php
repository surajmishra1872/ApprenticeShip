<?php
echo "<h1>Contact us</h1>";
//include '../server.php';
?>