<?php
echo "<h1> This is Public file welcome to my Framework</h1>";
//include "../server.php";
?>