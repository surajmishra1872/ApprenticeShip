<?php
//wap in php to print hello world
echo "Hello World";
?>