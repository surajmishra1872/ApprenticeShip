<?php
#wap in php to find sum of two number:
include 'scanner.php';
$x = input("Enter First number");
$y = input("Enter Second number");
$res = $x+$y;
//echo "the sum is  $res";
//echo "the sum is ".$res;
echo "the sum is ",$res;
/*
Multiple argument printing inphp any no of argument can be printed using echo but every argument must be seperated by comma(,) as seperator
*/
?>